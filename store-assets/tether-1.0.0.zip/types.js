"use strict";
// Shared types used by both the service worker and the anchor tab page.
